package TP2;

/**
 * The abstract type representing the LLVM instructions
 */
public abstract class Instruction {
    public abstract String toString();
}