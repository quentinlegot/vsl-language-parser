package TP2.ASD;

public abstract class AsdInstruction {

    public abstract String pp();
}
