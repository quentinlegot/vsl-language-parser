package TP2;

public class TypeException extends Exception {
  public TypeException(String message) {
    super(message);
  }
}
